﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusicStore.Data.Data;

namespace MusicStore.Data.CustomQueries
{
    public partial class SearchArtistsQueries
    {
        public List<MusicStore.Models.SearchArtistsModel> Search(string search_criteria, int page_number, int page_size)
        {
            using (var context = new MusicStoreEntities())
            {
                return context.SearchArtists(search_criteria, page_number, page_size).ToList();
            }
        }
    }
}
