﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security.OAuth;
using Newtonsoft.Json.Serialization;

namespace MusicStore.Api
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            // Configure Web API to use only bearer token authentication.
            config.SuppressDefaultHostAuthentication();
            config.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));

            // Web API routes
            config.MapHttpAttributeRoutes();


            config.Routes.MapHttpRoute(
                name: "Artist Details Api",
                routeTemplate: "Artist/search/{search_criteria}/{page_number}/{page_size}",
                defaults: new { controller = "Artist", action = "search", page_number = RouteParameter.Optional, page_size = RouteParameter.Optional }
            );
            config.Routes.MapHttpRoute(
               name: "Artist Name Api",
               routeTemplate: "Artist/search/{search_criteria}",
               defaults: new { controller = "Artist", action = "search" }
           );

            config.Routes.MapHttpRoute(
              name: "Artist Releases Api",
              routeTemplate: "Artist/{artist_id}/releases",
              defaults: new { controller = "Artist", action = "Releases" }
          );

            config.Routes.MapHttpRoute(
              name: "Artist Albums Api",
              routeTemplate: "Artist/{artist_id}/albums",
              defaults: new { controller = "Artist", action = "Albums" }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
