﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicStore.Api.Constant
{
    public static class Application
    {
        public static string Name
        {
            get
            {
                return "Music Store";
            }
        }
    }
}