﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace MusicStore.Api.Controllers
{
    public class ArtistController : ApiController
    {
        [HttpGet]
        public async Task<MusicStore.Models.Custom.SearchResult> search(string search_criteria, int? page_number, int? page_size)
        {
            var oModel = new MusicStore.Models.Custom.SearchResult();
            try
            {
                var oEngine = new MusicStore.Business.Custom.SearchEngine();
                if (!string.IsNullOrEmpty(search_criteria))
                {
                    oModel = await oEngine.Search(search_criteria, page_number, page_size);
                }
            }
            catch (Exception ex)
            {
                MusicStore.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStore.Api.Constant.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return oModel;
        }

        [HttpGet]
        public async Task<MusicStore.Models.Custom.SearchResult> search(string search_criteria)
        {
            var oModel = new MusicStore.Models.Custom.SearchResult();
            try
            {
                var oEngine = new MusicStore.Business.Custom.SearchEngine();
                if (!string.IsNullOrEmpty(search_criteria))
                {
                    oModel = await oEngine.Search(search_criteria, null, null);
                }
            }
            catch (Exception ex)
            {
                MusicStore.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStore.Api.Constant.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return oModel;
        }


        [HttpGet]
        public async Task<List<string>> Releases(string artist_id)
        {
            var oModel = new List<string>();
            try
            {
                var ArtistGuid = ConvertArtistId(artist_id);
                if (ArtistGuid != Guid.Empty)
                {
                    var oEngine = new MusicStore.Business.Custom.SearchEngine();
                    oModel = await oEngine.Releases(ArtistGuid);
                }
            }
            catch (Exception ex)
            {
                MusicStore.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStore.Api.Constant.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return oModel;
        }

         [HttpGet]
        public async Task<List<MusicStore.Models.Custom.Releases>> Albums(string artist_id)
        {
            var oModel = new List<MusicStore.Models.Custom.Releases>();
            try
            {
                var ArtistGuid = ConvertArtistId(artist_id);
                if (ArtistGuid != Guid.Empty)
                {
                    var oEngine = new MusicStore.Business.Custom.SearchEngine();
                    oModel = await oEngine.Albums(ArtistGuid);
                }
            }
            catch (Exception ex)
            {
                MusicStore.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStore.Api.Constant.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return oModel;
        }

        private Guid ConvertArtistId(string value)
        {
            Guid ArtistGuid = Guid.Empty;
            Guid.TryParse(value, out ArtistGuid);
            return ArtistGuid;
        }
    }
}
