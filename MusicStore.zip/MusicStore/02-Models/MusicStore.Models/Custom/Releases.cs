﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicStore.Models.Custom
{
    public class Releases
    {
        public string releaseId { get; set; }
        public string title { get; set; }
        public string status { get; set; }
        public string label { get; set; }
        public string numberOfTracks { get; set; }
        public MusicStore.Models.Custom.otherArtist[] otherArtists { get; set; }
    }
}
