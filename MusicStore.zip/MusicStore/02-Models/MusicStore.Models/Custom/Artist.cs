﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicStore.Models.Custom
{
    public class Artist
    {
        public string name { get; set; }
        public string country { get; set; }
        public string[] alias { get; set; }
        public string[] albums { get; set; }
    }
}
