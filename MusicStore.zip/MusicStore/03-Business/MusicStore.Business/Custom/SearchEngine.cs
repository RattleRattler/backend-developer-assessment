﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Hqub.MusicBrainz.API;
using Hqub.MusicBrainz.API.Entities;

namespace MusicStore.Business.Custom
{
    public partial class SearchEngine
    {

        #region "Encapsulated"
        private string[] FormatAliases(string aliases)
        {
            if (!string.IsNullOrEmpty(aliases))
            {
                return aliases.Split(',');
            }
            else
            {
                return new string[0];
            }
        }

        private MusicStore.Models.Artist LoadArtist(Guid artistguid)
        {
            var oModel = new MusicStore.Models.Artist();
            Expression<Func<MusicStore.Models.Artist, bool>> search = x => x.ArtistGuid == artistguid && x.Deleted == false;
            oModel = MusicStore.Business.Artists.ReadArtist(search);
            return oModel;
        }

        private async Task<List<MusicStore.Models.Custom.AlbumModel>> LoadAlbums(string artistId)
        {
            var oModel = new List<MusicStore.Models.Custom.AlbumModel>();

            var ReleasesList = await Release.BrowseAsync("artist", artistId, 100, 0, "media");
            foreach (var release in ReleasesList.Items)
            {
                var oRelease = new MusicStore.Models.Custom.AlbumModel
                {
                    id = release.Id,
                    name = release.Title
                };

                oModel.Add(oRelease);
            }
            return oModel;
        }

        private string FormatRelaseDate(string value)
        {
            DateTime _ReleaseDate;
            if (DateTime.TryParse(value, out _ReleaseDate))
            {
                return _ReleaseDate.Year.ToString();
            }
            else
            {
                return value;
            }
        }

        private string FormatReleaseLabel(List<LabelInfo> value)
        {
            if (value.Count > 0)
            {
                var oLabel = value.Where(x => x.Label != null).FirstOrDefault();
                if (oLabel != null)
                {
                    return oLabel.Label.Name;
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
        }
        #endregion

        #region "Exposed"
        public async Task<MusicStore.Models.Custom.SearchResult> Search(string search_criteria, int? page_number, int? page_size)
        {
            var pagenum = 0;
            if (page_number.HasValue)
            {
                if (page_number.Value <= 0)
                {
                    pagenum = 1;
                }
                else
                {
                    pagenum = page_number.Value;
                }
            }
            else
            {
                pagenum = 1;
            }

            var pagesize = 0;
            if (page_size.HasValue)
            {
                if (page_size.Value <= 0)
                {
                    pagesize = 1;
                }
                else
                {
                    pagesize = page_size.Value;
                }
            }
            else
            {
                pagesize = 5;
            }


            var oModel = new MusicStore.Models.Custom.SearchResult
            {
                page = pagenum,
                pageSize = pagesize
            };
            var oSearch = new MusicStore.Data.CustomQueries.SearchArtistsQueries();
            var oResults = oSearch.Search(search_criteria, pagenum, pagesize);
            if (oResults.Count > 0)
            {
                oModel.numberOfPages = oResults.First().PagesTotal;
                oModel.numberOfSearchResults = oResults.First().SearchTotal;
                oModel.results = new Models.Custom.Artist[oResults.Count];

                var indx = 0;
                foreach (var item in oResults)
                {
                    var AlbumList = await LoadAlbums(item.ArtistGuid.ToString());
                    var oArtist = new Models.Custom.Artist
                    {
                        name = item.ArtistName,
                        country = item.CountryCode,
                        alias = FormatAliases(item.Aliases),
                        albums = new string[AlbumList.Count()]
                    };

                    int x = 0;
                    foreach (var album in AlbumList)
                    {
                        oArtist.albums[x] = string.Format("http://musicbrainz.org/ws/2/release/?query=release:{0}", Uri.EscapeUriString(album.name));
                        x++;
                    }

                    oModel.results[indx] = oArtist;
                    indx = indx + 1;
                }
            }
            return oModel;
        }

        public async Task<List<string>> Releases(Guid artist_id)
        {
            var oModel = new List<string>();
            var oArtist = new MusicStore.Models.Artist();
            oArtist = LoadArtist(artist_id);
            if (oArtist != null)
            {
                var ReleasesList = await Release.SearchAsync(string.Format("arid:{0}", artist_id.ToString()), 100, 0);
                foreach (var release in ReleasesList.Items)
                {
                    oModel.Add(string.Format("http://musicbrainz.org/ws/2/release/?query=release:{0}", Uri.EscapeUriString(release.Title)));
                }
            }
            return oModel;
        }

        public async Task<List<MusicStore.Models.Custom.Releases>> Albums(Guid artist_id)
        {
            var oModel = new List<MusicStore.Models.Custom.Releases>();
            var oArtist = new MusicStore.Models.Artist();
            oArtist = LoadArtist(artist_id);
            if (oArtist != null)
            {
                var ReleasesList = await Release.SearchAsync(string.Format("arid:{0}", artist_id.ToString()), 100, 0);
                foreach (var release in ReleasesList.Items)
                {
                    var oRelease = new MusicStore.Models.Custom.Releases
                    {
                        releaseId = release.Id,
                        title = release.Title,
                        status = release.Status,
                        label = FormatReleaseLabel(release.Labels),
                        numberOfTracks = release.MediumList.TrackCount.ToString(),
                        otherArtists = new Models.Custom.otherArtist[release.Credits.Count]
                    };

                    int x = 0;
                    foreach(var oCredit in release.Credits)
                    {
                        oRelease.otherArtists[x] = new Models.Custom.otherArtist
                        {
                            id = oCredit.Artist.Id,
                            name = oCredit.Artist.Name
                        };
                        x++;
                    }

                    oModel.Add(oRelease);
                }
            }
            return oModel;
        }
        #endregion

        #region "Static"
        #endregion
    }
}
