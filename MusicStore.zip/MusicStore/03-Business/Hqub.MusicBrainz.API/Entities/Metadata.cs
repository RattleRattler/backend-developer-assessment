﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hqub.MusicBrainz.API.Entities
{
    public abstract class MetadataWrapper : Entity
	{

	}
}
